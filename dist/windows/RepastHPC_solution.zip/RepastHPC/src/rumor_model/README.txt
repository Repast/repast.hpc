
This is the bin directory for the sample rumor model. Run with:

/usr/local/bin/mpirun -np 6 ./rumor_model -config 
./config.props -properties ./rumor.props

Adjusting the location of mpirun as necessary.
