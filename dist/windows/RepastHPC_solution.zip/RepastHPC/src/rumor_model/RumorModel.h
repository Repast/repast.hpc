/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * RumorModel.h
 *
 *  Created on: Jun 9, 2009
 *      Author: nick
 */

#ifndef RUMORMODEL_H_
#define RUMORMODEL_H_

#include "repast_hpc/TDataSource.h"
#include "repast_hpc/SVDataSet.h"
#include "repast_hpc/SharedContext.h"
#include "repast_hpc/Schedule.h"
#include "repast_hpc/SharedNetwork.h"
#include "repast_hpc/Edge.h"
#include "repast_hpc/Random.h"
#include "repast_hpc/Properties.h"
#include "repast_hpc/Utilities.h"

#include <boost/serialization/access.hpp>

struct NodeContent {

	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive& ar, const unsigned int version) {
		ar & id;
		ar & proc;
		ar & type;
		ar & rumored;
	}

	int id, proc, type;
	bool rumored;

	repast::AgentId getId() const {
		return repast::AgentId(id, proc, type);
	}
};

struct EdgeContent {

	friend class boost::serialization::access;
		template<class Archive>
		void serialize(Archive& ar, const unsigned int version) {
			ar & sourceContent;
			ar & targetContent;
		}

		// source and target agents
		NodeContent sourceContent, targetContent;
};


class Node: public repast::Agent {

	friend class boost::serialization::access;

private:
	repast::AgentId id_;
	bool rumored_;
	double rProb;
	std::string distName_;

	// TODO remove this when edges use content sending
	// rather than the whole agent
	template<class Archive>
	void serialize(Archive& ar, const unsigned int version) {
		ar & boost::serialization::base_object<Agent>(*this);
		ar & id_;
		ar & rumored_;
	}

public:
	// TODO remove no-arg ctor when edge sending uses content
	// for end points
	// no-arg constructor for serialization
	Node() {}
	Node(repast::AgentId id, double probability, std::string distName);
	virtual ~Node();

	/**
	 * Updates this Node's rumored state with that of the
	 * specified node.
	 */
	void update(Node* node);

	void init(double prob, std::string dist);

	bool rumored() const {
		return rumored_;
	}

	void rumored(bool val) {
		rumored_ = val;
	}

	/**
	 * Makes the draw against a distribtion to see
	 * if this node receives the rumor.
	 */
	bool receiveRumor();

	virtual repast::AgentId& getId() {
		return id_;
	}

	virtual const repast::AgentId& getId() const {
			return id_;
		}
};

/**
 * DataSource that sums the number of nodes that have
 * been "rumored."
 */
class RumoredSum: public repast::TDataSource<int> {

private:
	repast::SharedContext<Node>* nodes_;
	int sum;
	bool doCount;

public:
	RumoredSum(repast::SharedContext<Node>* nodes);
	int getData();
	void reset() {
		doCount = true;
	}
};

class ProviderReceiver;

class RumorModel /*: public repast::AgentUpdater*/{

private:
	friend class ProviderReceiver;

	repast::SharedContext<Node> nodes;
	repast::SharedNetwork<Node, repast::RepastEdge<Node> >* net;
	repast::SVDataSet* dataSet;
	int rank, stopAt, totalNodes;
	int lastRumorSum, noChangeCount;
	repast::Properties props;

	// set of Nodes that are currently rumored
	std::set<Node*> rumored;
	RumoredSum* rumorSum;

	void buildNetwork(repast::Properties& props);
	int initializeNodes(repast::Properties& props);
	void initializeRumoredNodes(int numNodes, repast::Properties& props);

public:
	RumorModel(const std::string& propsFile);
	virtual ~RumorModel();

	void initSchedule(repast::ScheduleRunner& runner);
	void spreadRumor();
	void checkForStop();
	void logRumorSum();
	void synchAgents();
	void initNode(Node* node);
	void init();

	void provideContent(const repast::AgentRequest& request, std::vector<NodeContent>& out);
	void provideEdgeContent(const repast::RepastEdge<Node>* edge, std::vector<EdgeContent>& edgeContent);
	repast::RepastEdge<Node>* createEdge(repast::Context<Node>& context, EdgeContent& edge);
	void updateAgent(const NodeContent& content);


};

class NodeAdder {
private:
	RumorModel* network_;

public:
	NodeAdder(RumorModel* network);
	Node* createAgent(const NodeContent& content);
};

#endif /* RUMORMODEL_H_ */
