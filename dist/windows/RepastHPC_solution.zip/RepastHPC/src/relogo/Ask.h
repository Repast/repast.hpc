/*
 * Ask.h
 *
 *  Created on: Jul 15, 2010
 *      Author: nick
 */

#ifndef ASK_H_
#define ASK_H_

#include "Observer.h"

namespace repast {
namespace relogo {


struct StackFrame {

};

template <typename Target, typename Functor>
void ask(Target& self, Functor functor) {
	// TODO get real observer
	Observer obs;
	functor(self, obs);
}


template <typename Target, typename Myself, typename Functor>
void ask(Target& self, Myself& myself, Functor functor) {
	functor(self, myself);
}

template <typename InputIterator, typename Functor>
void ask(InputIterator begin, InputIterator end, Functor functor) {
	// TODO get real observer
	Observer obs;
	for (; end != begin; ++begin) {
		functor(*begin, obs);
	}
}

}
}

#endif /* ASK_H_ */
