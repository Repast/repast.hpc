/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * SharedConext.hpp
 *
 *  Created on: Jun 18, 2009
 *      Author: nick
 */

#ifndef SHAREDCONEXT_HPP_
#define SHAREDCONEXT_HPP_

#include "Context.h"

#include <boost/mpi.hpp>
#include <exception>

namespace repast {

// used in a filter iterator to
// filter on local agents only
/**
 * NON USER API
 */
template<typename T>
struct IsLocalAgent {
	int rank;
	IsLocalAgent() {
		boost::mpi::communicator world;
		rank = world.rank();
	}

	bool operator()(const boost::shared_ptr<T>& ptr) {
		//std::cout << "id: " << std::endl;
		//std::cout <<  "\t" << ptr->getId() << std::endl;
		return ptr->getId().currentRank() == rank;
	}

};

/**
 * NON USER API.
 *
 * Used to remove agents.
 */
void rpRemoveAgent(const AgentId& id);


/**
 * Context implementation specialized for the parallel distributed
 * simulation. A SharedContext contains both local, that is, agents
 * whose behavior is run on the SharedContext's process and foreign agents,
 * that is, copies of agents whose behavior is run on some other process.
 *
 * @param T the type of agents in the context.
 */
template<typename T>
class SharedContext: public Context<T> {

private:

	typedef typename boost::unordered_map<AgentId, int, HashId> RefMap;

	// holds reference count to foreign agents that are
	// referenced by projections. If a projection removes an
	// agent from a context, this should be checked to make sure
	// no other projections hold a reference before actually deleting
	// the agent.
	RefMap projRefMap;
	int _rank;

public:

	typedef typename boost::filter_iterator<IsLocalAgent<T> , typename Context<T>::const_iterator> const_local_iterator;

	SharedContext();
	virtual ~SharedContext();

	/**
	 * Gets the start of iterator over the local agents in this context.
	 * The iterator derefrences into shared_ptr<T>. The actual
	 * agent can be accessed by dereferencing the iter: (*iter)->getId() for example.
	 *
	 * @return the start of iterator over the local agents in this context.
	 */
	const_local_iterator localBegin() const;

	/**
	 * Gets then end of an iterator over the local agents in this context.
	 * The iterator derefrences into shared_ptr<T>. The actual
	 * agent can be accessed by derefrenceing the iter: (*iter)->getId() for example.
	 */
	const_local_iterator localEnd() const;

	/**
	 * Removes the specified agent from this context. If the
	 * agent is non-local, this checks to make sure that it
	 * is not referenced by any projection before its removed.
	 *
	 * @param id the id of the agent to remove
	 */
	void removeAgent(const AgentId id);

	/**
	 * Removes the specified agent from this context. If the
	 * agent is non-local, this checks to make sure that it
	 * is not referenced by any projection before its removed.
	 *
	 * @param agent the agent to remove
	 */
	void removeAgent(T* agent);

	/**
	 * Notifies this context that the specified non-local agent
	 * has been removed and this context should then delete that
	 * agent from itself.
	 *
	 * @param id the id of the agent that was removed
	 */
	void importedAgentRemoved(const AgentId& id);

	/**
	 * Increments the projection reference count for the specified
	 * agent.
	 *
	 * @param id the id of the agent
	 */
	void incrementProjRefCount(const AgentId& id);

	/**
	 * Decrements the projection reference count for the specified agent.
	 *
	 * @param id the id of the agent
	 */
	void decrementProjRefCount(const AgentId& id);

};

template<typename T>
SharedContext<T>::SharedContext() :
	Context<T> (), _rank(0) {
	boost::mpi::communicator world;
	_rank = world.rank();
}

template<typename T>
SharedContext<T>::~SharedContext() {
}

template<typename T>
void SharedContext<T>::removeAgent(T* agent) {
	removeAgent(agent->getId());
}

template<typename T>
void SharedContext<T>::removeAgent(const AgentId id) {
	if (id.currentRank() != _rank) {
		if (projRefMap.find(id) == projRefMap.end()) {
			Context<T>::removeAgent(id);
		}
	} else {
		Context<T>::removeAgent(id);
		rpRemoveAgent(id);
	}
}

template <typename T>
void SharedContext<T>::importedAgentRemoved(const AgentId& id) {
	projRefMap.erase(id);
	Context<T>::removeAgent(id);
}

template<typename T>
void SharedContext<T>::incrementProjRefCount(const AgentId& id) {
	if (id.currentRank() != _rank) {
		RefMap::iterator iter = projRefMap.find(id);
		if (iter == projRefMap.end()) {
			projRefMap[id] = 1;
		} else {
			projRefMap[id] = ++(iter->second);
		}
	}
}

template<typename T>
void SharedContext<T>::decrementProjRefCount(const AgentId& id) {
	if (id.currentRank() != _rank) {
		RefMap::iterator iter = projRefMap.find(id);
		if (iter == projRefMap.end()) {
			throw std::invalid_argument("Id is not in the projection reference map");
		} else {
			int count = --(iter->second);
			if (count == 0)
				projRefMap.erase(iter);
			else
				projRefMap[id] = count;
		}
	}
}

template<typename T>
boost::filter_iterator<IsLocalAgent<T> , typename Context<T>::const_iterator> SharedContext<T>::localBegin() const {
	IsLocalAgent<T> predicate;
	return const_local_iterator(predicate, Context<T>::begin(), Context<T>::end());
}

template<typename T>
boost::filter_iterator<IsLocalAgent<T> , typename Context<T>::const_iterator> SharedContext<T>::localEnd() const {
	IsLocalAgent<T> predicate;
	return const_local_iterator(predicate, Context<T>::end(), Context<T>::end());
}

}

#endif /* SHAREDCONEXT_HPP_ */
