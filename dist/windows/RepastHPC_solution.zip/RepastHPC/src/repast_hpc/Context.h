/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Context.h
 *
 *  Created on: May 22, 2009
 *      Author: nick
 */

#ifndef CONTEXT_H_
#define CONTEXT_H_

#include "AgentId.h"
#include "Random.h"
#include "ValueLayer.h"
#include "Projection.h"

#include <boost/unordered_map.hpp>
#include <boost/smart_ptr.hpp>
#include <boost/iterator/transform_iterator.hpp>
#include <boost/iterator/filter_iterator.hpp>
#include <boost/function.hpp>

namespace repast {

// Unary function used in the transform_iterator that allows context iterators
// to return the agent maps values.
template<typename T>
struct SecondElement: public std::unary_function<
		typename boost::unordered_map<AgentId, boost::shared_ptr<T> >::value_type, boost::shared_ptr<T> > {
	boost::shared_ptr<T> operator()(
			const typename boost::unordered_map<AgentId, boost::shared_ptr<T> >::value_type& value) const {
		const boost::shared_ptr<T>& ptr = value.second;
		//std::cout << ptr->getId() << std::endl;
		return ptr;
	}
};

/**
 * Collection of agents of type T with set semantics. Object identity and equality
 * is determined by their AgentId.
 *
 * @tparam the type objects contained by the Context. The T must extends repast::Agent.
 */
template<typename T>
class Context {

private:

	typedef typename std::vector<Projection<T>*>::iterator ProjPtrIter;
	typedef typename boost::unordered_map<AgentId, boost::shared_ptr<T>, HashId> AgentMap;

	typedef typename AgentMap::iterator AgentMapIterator;
	typedef typename AgentMap::const_iterator AgentMapConstIterator;

	AgentMap agents;
	std::vector<Projection<T> *> projections;
	std::map<std::string, BaseValueLayer*> valueLayers;

public:

	typedef typename boost::transform_iterator<SecondElement<T> , typename AgentMap::const_iterator> const_iterator;
	typedef typename boost::filter_iterator<IsAgentType<T> , typename Context<T>::const_iterator> const_bytype_iterator;

	Context();

	/**
	 * Destroys this context and the projections it contains.
	 */
	virtual ~Context();

	/**
	 * Adds the agent to the context. Returns true if the
	 * agent is added, or false if an agent with the same
	 * id is already in the context.
	 *
	 * @param agent the agent to add
	 *
	 * @return true if the agent is successfully dded, or false if an agent with the same
	 * id is already in the context.
	 */
	bool addAgent(T* agent);

	/**
	 * Adds the specified projection to this context. All the agents in this
	 * context will be added to the Projection. Any agents subsequently added
	 * to this context will also be added to the Projection.
	 *
	 * @param projection the projection to add
	 */
	void addProjection(Projection<T>* projection);

	/**
	 * Get the named Projection.
	 *
	 * @param the name of the projection to get
	 *
	 * @return the named Projection or 0 if no such Projection is found.
	 */
	Projection<T>* getProjection(const std::string& name);

	/**
	 * Removes the specified agent from this context.
	 *
	 * @param id the id of the agent to remove
	 */
	void removeAgent(const AgentId id);

	/**
	 * Removes the specified agent from this context.
	 */
	void removeAgent(T* agent);

	/**
	 * Gets the specified agent.
	 *
	 * @param the id of the agent to get.
	 */
	T* getAgent(const AgentId& id);

	/**
	 * Gets at random the specified count of agents and returns them
	 * in the agents vector.
	 *
	 * @param count the number of agents to get
	 * @param [out] agents a vector where the agents will be returned
	 */
	void getRandomAgents(const int count, std::vector<T*>& agents);

	/**
	 * Gets the start of iterator over the agents in this context.
	 * The iterator derefrences into shared_ptr<T>. The actual
	 * agent can be accessed by derefrenceing the iter: (*iter)->getId() for example.
	 *
	 * @return the start of iterator over the agents in this context.
	 */
	const_iterator begin() const {
		return const_iterator(agents.begin());
	}

	/**
	 * Gets the end of an iterator over the agents in this context. The iterator derefrences
	 * into shared_ptr<T>. The actual agent can be accessed by derefrenceing the iter:
	 * (*iter)->getId() for example.
	 *
	 * @return  the end of an iterator over the agents in this context
	 */
	const_iterator end() const {
		return const_iterator(agents.end());
	}

	/**
	 * Gets the start of an iterator over agents in this context of the specified type. The type
	 * corresponds to the type component of an agent's AgentId.
	 *
	 * @param typeId the type of the agent. Only Agents whose agentId.agentType() is equal to
	 * this typeId will be included in the iterator
	 *
	 * @return the start of an iterator over agents in this context of the specified type.
	 */
	const_bytype_iterator byTypeBegin(int typeId) const {
		return const_bytype_iterator(IsAgentType<T> (typeId), Context<T>::begin(), Context<T>::end());
	}

	/**
	 * Gets the end of an iterator over agents in this context of the specified type. The type
	 * corresponds to the type component of an agent's AgentId.
	 *
	 * @param typeId the type of the agent. Only Agents whose agentId.agentType() is equal to
	 * this typeId will be included in the iterator
	 *
	 * @return the end of an iterator over agents in this context of the specified type.
	 */
	const_bytype_iterator byTypeEnd(int typeId) const {
		return const_bytype_iterator(IsAgentType<T> (typeId), Context<T>::end(), Context<T>::end());
	}

	/**
	 * Returns true if the specified agent is in this context, otherwise false.
	 */
	bool contains(const AgentId& id);

	/**
	 * Gets the size (number of agents) in this context.
	 */
	int size() const {
		return agents.size();
	}

	/**
	 * Adds a value layer to this context.
	 *
	 * @param valueLayer the value layer to add
	 */
	void addValueLayer(BaseValueLayer* valueLayer);

	/**
	 * Gets the named discrete value layer from this Context. The value layer must have been
	 * previously added.
	 *
	 * @param valueLayerName the name of the value layer to get
	 *
	 * @tparam ValueType the numeric type contained by the value layer
	 * @tparam Borders the Border type of the value layer
	 *
	 * @return the named discrete value layer from this Context.
	 */
	template<typename ValueType, typename Borders>
	DiscreteValueLayer<ValueType, Borders>* getDiscreteValueLayer(const std::string& valueLayerName);

	/**
	 * Gets the named continuous value layer from this Context. The value layer must have been
	 * previously added.
	 *
	 * @param valueLayerName the name of the value layer to get
	 *
	 * @tparam ValueType the numeric type contained by the value layer
	 * @tparam Borders the Border type of the value layer
	 *
	 * @return the named continuous value layer from this Context.
	 */
	template<typename ValueType, typename Borders>
	ContinuousValueLayer<ValueType, Borders>* getContinuousValueLayer(const std::string& valueLayerName);
};

template<typename T>
Context<T>::Context() {
}

template<typename T>
Context<T>::~Context() {
	agents.erase(agents.begin(), agents.end());
	for (ProjPtrIter iter = projections.begin(); iter != projections.end(); ++iter) {
		Projection<T>* proj = *iter;
		delete proj;
	}
	projections.clear();

	for (std::map<std::string, BaseValueLayer*>::iterator iter = valueLayers.begin(); iter != valueLayers.end(); ++iter) {
		BaseValueLayer* layer = iter->second;
		delete layer;
	}
	valueLayers.clear();
}

template<typename T>
void Context<T>::addProjection(Projection<T>* projection) {
	if (find(projections.begin(), projections.end(), projection) != projections.end())
		throw std::invalid_argument("Projection '" + projection->name() + "' is already contained in the context");

	for (const_iterator iter = begin(); iter != end(); ++iter) {
		projection->addAgent(*iter);
	}
	projections.push_back(projection);
}

template<typename T>
Projection<T>* Context<T>::getProjection(const std::string& name) {
	for (ProjPtrIter iter = projections.begin(); iter != projections.end(); ++iter) {
		Projection<T>* proj = *iter;
		if (proj->name() == name)
			return proj;
	}
	return NULL;
}

template<typename T>
T* Context<T>::getAgent(const AgentId& id) {
	AgentMapIterator iter = agents.find(id);
	if (iter == agents.end())
		return 0;
	return iter->second.get();
}

template<typename T>
void Context<T>::getRandomAgents(const int count, std::vector<T*>& agents) {
	for (int i = 0; i < count; i++) {
		IntUniformGenerator rnd = Random::instance()->createUniIntGenerator(0, size() - 1);
		bool found = false;
		while (!found) {
			const_iterator iter = begin();
			for (int j = 0, n = rnd.next(); j < n; iter++, j++)
				;
			T* agent = iter->get();
			if (find(agents.begin(), agents.end(), agent) == agents.end()) {
				agents.push_back(agent);
				found = true;
			}
		}
	}
}

template<typename T>
bool Context<T>::addAgent(T* agent) {
	const AgentId& id = agent->getId();
	if (agents.find(id) != agents.end())
		return false;

	boost::shared_ptr<T> ptr(agent);
	agents[id] = ptr;

	for (ProjPtrIter iter = projections.begin(); iter != projections.end(); ++iter) {
		Projection<T>* proj = *iter;
		proj->addAgent(ptr);
	}

	return true;
}

template<typename T>
void Context<T>::removeAgent(T* agent) {
	removeAgent(agent->getId());
}

template<typename T>
void Context<T>::removeAgent(const AgentId id) {
	const AgentMapIterator iter = agents.find(id);
	if (iter != agents.end()) {
		boost::shared_ptr<T>& ptr = iter->second;
		for (ProjPtrIter pIter = projections.begin(); pIter != projections.end(); ++pIter) {
			Projection<T>* proj = *pIter;
			proj->removeAgent(ptr.get());
		}
		agents.erase(iter);
	}
}

template<typename T>
bool Context<T>::contains(const AgentId& id) {
	return agents.find(id) != agents.end();
}

template<typename T>
void Context<T>::addValueLayer(BaseValueLayer* layer) {
	valueLayers[layer->name()] = layer;
}

template<typename T>
template<typename ValueType, typename Borders>
DiscreteValueLayer<ValueType, Borders>* Context<T>::getDiscreteValueLayer(const std::string& valueLayerName) {

	std::map<std::string, BaseValueLayer*>::iterator iter = valueLayers.find(valueLayerName);
	if (iter == valueLayers.end())
		return 0;
	return static_cast<DiscreteValueLayer<ValueType, Borders>*> (iter->second);
}

template<typename T>
template<typename ValueType, typename Borders>
ContinuousValueLayer<ValueType, Borders>* Context<T>::getContinuousValueLayer(const std::string& valueLayerName) {

	std::map<std::string, BaseValueLayer*>::iterator iter = valueLayers.find(valueLayerName);
	if (iter == valueLayers.end())
		return 0;
	return static_cast<ContinuousValueLayer<ValueType, Borders>*> (iter->second);
}

}

#endif /* CONTEXT_H_ */
