/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * AgentRequest.cpp
 *
 *  Created on: Aug 19, 2010
 *      Author: nick
 */

#include <vector>
#include "AgentRequest.h"

using namespace std;

namespace repast {

AgentRequest::AgentRequest(int sourceProcess) :
	source(sourceProcess), target(-1) {
}

AgentRequest::AgentRequest(int sourceProcess, int targetProcess) :
	source(sourceProcess), target(targetProcess) {
}

void AgentRequest::addRequest(const AgentId& id) {
	requestedAgents_.push_back(id);
}

bool AgentRequest::contains(const AgentId& id) {
	return find(requestedAgents_.begin(), requestedAgents_.end(), id) != requestedAgents_.end();
}

std::ostream& operator<<(std::ostream& os, const AgentRequest& request) {
	os << "AgentRequest(" << request.source << ", " << request.target << " [";

	bool comma = false;
	for (vector<AgentId>::const_iterator it = request.requestedAgents_.begin(); it != request.requestedAgents_.end(); it++) {
		if (comma)
			os << ", ";
		os << *it;
		comma = true;
	}
	os << "]";
	return os;
}

bool AgentRequest::remove(const AgentId& id) {
	bool retVal = false;
	for (vector<AgentId>::iterator iter = requestedAgents_.begin(); iter != requestedAgents_.end(); ) {
		if ((*iter) == id) {
			iter = requestedAgents_.erase(iter);
			retVal = true;
		} else {
			++iter;
		}
	}
	return retVal;
}

void AgentRequest::addAll(const AgentRequest& req) {
	requestedAgents_.insert(requestedAgents_.end(), req.requestedAgents_.begin(), req.requestedAgents_.end());
}

void AgentRequest::targets(set<int>& targets) {
	for (int i = 0, n = requestedAgents_.size(); i < n; i++) {
		AgentId& id = requestedAgents_[i];
		int target = id.currentRank();
		targets.insert(target);
	}
}

}
