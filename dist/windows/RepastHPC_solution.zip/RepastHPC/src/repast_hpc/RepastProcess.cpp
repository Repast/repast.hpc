/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * RepastProcess.cpp
 *
 *  Created on: Jan 5, 2009
 *      Author: nick
 */
#include <map>
#include <algorithm>
#include <utility>
#include <exception>
#include <boost/mpi.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

#include "RepastProcess.h"
#include "logger.h"
#include "mpiio.h"
#include "Utilities.h"
#include "RequestManager.h"

using namespace std;
namespace mpi = boost::mpi;

namespace repast {

RepastProcess* RepastProcess::_instance = 0;

RepastProcess::RepastProcess() {
	rank_ = world.rank();
	worldSize_ = world.size();
}

RepastProcess* RepastProcess::init(string propsfile) {
	if (_instance == 0) {
		mpi::communicator world;
		// configure logging
		if (propsfile.length() > 0) Log4CL::configure(world.rank(), propsfile);
		else Log4CL::configure(world.rank());
		_instance = new RepastProcess();
	}
	return _instance;
}

RepastProcess* RepastProcess::instance() {
	if (_instance == 0) throw domain_error("RepastProcess must be initialized before calling instance");
	return _instance;
}

void RepastProcess::done() {
	Log4CL::instance()->close();
}

/*
 void RepastProcess::syncAgentState(AgentProvider& provider, AgentUpdater& updater) {
 vector<boost::mpi::request> requests;
 importer.startSyncState(world, requests);
 exporter.syncState(provider, world, requests);
 boost::mpi::wait_all(requests.begin(), requests.end());
 importer.finish(updater);
 }
 */

void RepastProcess::updateExporters() {
	// update importing ranks to import from the process
	// where an agent as moved to.
	vector<int> exportersToUpdate;
	for (map<int, vector<AgentRequest>*>::iterator iter = importers.begin(); iter != importers.end(); ++iter) {
		exportersToUpdate.push_back(iter->first);
	}

	vector<int> senders;
	SRManager manager(world);
	manager.retrieveSources(exportersToUpdate, senders, EXPORTER_UPDATE_SENDERS);

	vector<mpi::request> requests;
	// isend
	for (map<int, vector<AgentRequest>*>::iterator iter = importers.begin(); iter != importers.end(); ++iter) {
		requests.push_back(world.isend(iter->first, EXPORTER_UPDATE_IMPORTERS, *(iter->second)));
	}

	// should now have list of senders to that we should receive from
	vector<AgentRequest> importersToAdd;
	for (vector<int>::iterator iter = senders.begin(); iter != senders.end(); ++iter) {
		int sender = *iter;
		requests.push_back(world.irecv(sender, EXPORTER_UPDATE_IMPORTERS, importersToAdd));
	}

	boost::mpi::wait_all(requests.begin(), requests.end());

	// notifies the P at this rank that it should now export -- fulfilling the specified requests
	for (vector<AgentRequest>::iterator iter = importersToAdd.begin(); iter != importersToAdd.end(); ++iter) {
		AgentRequest req = *iter;
		//std::cout << rank_ << std::endl;
		for (vector<AgentId>::const_iterator vIter = req.requestedAgents().begin(); vIter
				!= req.requestedAgents().end(); ++vIter) {
			// don't add agents that are exported by me to be imported by me
			if (req.sourceProcess() != rank_)
				addExportedAgent(req.sourceProcess(), *vIter);
		}
	}
}

void RepastProcess::addExportedAgent(int importingProcess, AgentId id) {
	exporter.addExportedAgent(importingProcess, id);
}

void RepastProcess::addImportedAgent(AgentId id) {
	importer.incrementImportedAgentCount(id.currentRank());
}

void RepastProcess::agentRemoved(const AgentId& id) {
	movedAgents.erase(id);
	exporter.agentRemoved(id);
}

void RepastProcess::moveAgent(const AgentId& id, int process) {
	MovedAgentSetType::const_iterator iter = movedAgents.find(id);
	if (iter == movedAgents.end()) {
		AgentId newId(id);
		newId.currentRank(process);
		movedAgents.insert(newId);
		map<int, vector<AgentRequest>*>::iterator iter = importers.find(process);
		if (iter == importers.end()) {
			vector<AgentRequest>* tmp = new vector<AgentRequest> ();
			exporter.agentMoved(id, process, *tmp);
			if (tmp->size() == 0) {
				delete tmp;
			} else {
				importers[process] = tmp;
			}
		} else {
			exporter.agentMoved(id, process, *(iter->second));
		}
	} else {
		AgentId other = *iter;
		if (other.currentRank() != process) {
			std::cout << rank_ << " : " << other << ", " << id << " trying to move to " << process << std::endl;
			throw std::domain_error("Cannot move agent to two different processes during the same iteration");
		}
	}
}

void RepastProcess::initiateAgentRequest(AgentRequest &request) {
	RequestManager *receiver = 0;

	// gather the request counts
	int numRequests = request.requestCount();
	if (rank_ == 0) {
		receiver = new RequestManager(worldSize_);
		vector<int>& requestCounts = receiver->requestCounts();

		//Timer t;
		//t.start();
		gather(world, numRequests, requestCounts, 0);
		//Log4CL::instance()->get_logger("root").log(INFO, "ra_gather, time: " + boost::lexical_cast<
		//		std::string>(t.stop()));
	} else {
		//Timer t;
		//t.start();
		gather(world, numRequests, 0);
		//Log4CL::instance()->get_logger("root").log(INFO, "ra_gather, time: " + boost::lexical_cast<
		//		std::string>(t.stop()));
	}

	if (rank_ == 0) {
		// proc 0 receives the requests
		receiver->receiveRequests();
		// process any requests that proc 0 makes
		if (numRequests > 0) {
			receiver->mapRequest(request);
		}
	} else {
		// other procs send their requests
		if (numRequests > 0) {
			//Timer t;
			//t.start();

			world.send(0, AGENT_REQUEST_TAG, request);
			//Log4CL::instance()->get_logger("root").log(INFO, "ra_send, time: "
			//		+ boost::lexical_cast<std::string>(t.stop()));
		}
	}

	vector<AgentRequest> requestsToFulfill;// = 0;
	vector<vector<AgentRequest> > allReqs;
	if (rank_ == 0) {
		allReqs.assign(worldSize_, vector<AgentRequest>());
		receiver->fillRequests(world, allReqs);
	}

	//Timer t;
	//t.start();
	scatter(world, allReqs, requestsToFulfill, 0);
	//Log4CL::instance()->get_logger("root").log(INFO, "ra_scatter_reqs, time: " + boost::lexical_cast<
	//		std::string>(t.stop()));
	if (rank_ == 0) {
		vector<AgentRequest>* req = receiver->requestsFor(0);
		if (req != 0)
			requestsToFulfill = *(req);
	}

	//vector<boost::mpi::request> requests;
	if (numRequests > 0) {
		boost::unordered_set<AgentId, HashId> set;
		const std::vector<AgentId>& requestedIds = request.requestedAgents();
		std::vector<AgentId>::const_iterator iter;
		for (iter = requestedIds.begin(); iter != requestedIds.end(); ++iter) {
			if (set.find(*iter) == set.end()) {
				importer.incrementImportedAgentCount(iter->currentRank());
				set.insert(*iter);
			}
		}
	}

	if (requestsToFulfill.size() > 0) {// != 0) {
		exporter.updateExportedAgents(&requestsToFulfill);
	}

	delete receiver;
	//std::cout << world.rank() << " init request done" << std::endl;
}

RepastProcess::~RepastProcess() {
	_instance = 0;
}

}

