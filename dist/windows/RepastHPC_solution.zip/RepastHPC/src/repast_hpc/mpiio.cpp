/*
*Repast for High Performance Computing (Repast HPC)
*
*   Copyright (c) 2010 Argonne National Laboratory
*   All rights reserved.
*  
*   Redistribution and use in source and binary forms, with 
*   or without modification, are permitted provided that the following 
*   conditions are met:
*  
*  	 Redistributions of source code must retain the above copyright notice,
*  	 this list of conditions and the following disclaimer.
*  
*  	 Redistributions in binary form must reproduce the above copyright notice,
*  	 this list of conditions and the following disclaimer in the documentation
*  	 and/or other materials provided with the distribution.
*  
*  	 Neither the name of the Argonne National Laboratory nor the names of its
*     contributors may be used to endorse or promote products derived from
*     this software without specific prior written permission.
*  
*   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
*   PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE TRUSTEES OR
*   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
*   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
*   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
*   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
*   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
*   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
*   EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * mpiio.cpp
 *
 *  Created on: Sep 17, 2009
 *      Author: nick
 */

#include "mpiio.h"

#include <map>
#include <boost/mpi.hpp>

using namespace std;
using namespace boost;

SRManager::SRManager(mpi::communicator comm) :
	_comm(comm), rank(comm.rank()), worldSize(comm.size()) {
}

void SRManager::retrieveSources(const std::vector<int>& targets, std::vector<int>& sources, int tag) {
	if (rank == 0) {
		vector<vector<int> > allTargets;
		// gather the lists of targets -- one from each process
		gather(_comm, targets, allTargets, 0);

		// sort the lists into map -- where the key is the process
		// that will be sent to, and the value is a vector containing
		// the processes that will send to the key.
		map<int, vector<int>*> sendMap;
		for (size_t from = 0; from < allTargets.size(); from++) {
			vector<int> to = allTargets[from];
			for (size_t i = 0; i < to.size(); i++) {
				map<int, vector<int>*>::iterator iter = sendMap.find(to[i]);
				vector<int>* vec;
				if (iter == sendMap.end()) {
					vec = new vector<int> ();
					sendMap[to[i]] = vec;
				} else {
					vec = iter->second;
				}
				vec->push_back(from);
			}
		}

		// send the vector containing p's that will send
		// to the process that will receive those sends.
		// if no sends then, send a dummy empty vector.
		vector<int> dummy;
		for (int i = 1; i < worldSize; i++) {
			map<int, vector<int>*>::iterator iter = sendMap.find(i);
			if (iter == sendMap.end()) {
				_comm.send(i, tag, dummy);
			} else {
				_comm.send(i, tag, *(iter->second));
				delete iter->second;
			}
		}

		// for rank 0, insert the senders into the sources list
		map<int, vector<int>*>::iterator iter = sendMap.find(0);
		if (iter != sendMap.end()) {
			sources.insert(sources.end(), iter->second->begin(), iter->second->end());
			delete iter->second;
		}

	} else {
		gather(_comm, targets, 0);
		if (sources.size() == 0) {
			_comm.recv(0, tag, sources);
		} else {
			// if sources is not empty the recv will overwrite the
			// current entries, so use tmp vector to store the data.
			vector<int> tmp;
			_comm.recv(0, tag, tmp);
			sources.insert(sources.end(), tmp.begin(), tmp.end());
		}
	}
}
